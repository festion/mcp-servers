GitOps Dashboard Deployment Package

To install:
1. Copy this entire directory to your production server
2. SSH into your production server
3. Navigate to the copied directory
4. Run: ./install.sh

This will install the dashboard, API, and required scripts.
