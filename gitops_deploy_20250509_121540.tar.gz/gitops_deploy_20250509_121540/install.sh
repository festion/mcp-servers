#\!/bin/bash
set -e

# Target directories
TARGET_DIR="/opt/gitops"
WEB_DIR="/var/www/gitops-dashboard"

# Create directories if they don't exist
mkdir -p "${TARGET_DIR}/api"
mkdir -p "${TARGET_DIR}/scripts"
mkdir -p "${TARGET_DIR}/logs"
mkdir -p "${WEB_DIR}"

# Copy dashboard files to web directory
echo "Installing dashboard files..."
cp -r dashboard/* "${WEB_DIR}/"

# Copy API files
echo "Installing API files..."
cp -r api/* "${TARGET_DIR}/api/"

# Copy scripts
echo "Installing scripts..."
cp -r scripts/* "${TARGET_DIR}/scripts/"

# Make scripts executable
chmod +x "${TARGET_DIR}/scripts/"*.sh

# Install API dependencies
echo "Installing API dependencies..."
cd "${TARGET_DIR}/api"
npm install express

# Setup systemd service for API
echo "Setting up API service..."
cat > /etc/systemd/system/gitops-audit-api.service << 'SERVICEDEF'
[Unit]
Description=GitOps Audit API Server
After=network.target

[Service]
ExecStart=/usr/bin/node /opt/gitops/api/server.js
WorkingDirectory=/opt/gitops/api
Restart=always
RestartSec=10
Environment=NODE_ENV=production
User=root

[Install]
WantedBy=multi-user.target
SERVICEDEF

# Reload and enable service
systemctl daemon-reload
systemctl enable --now gitops-audit-api

echo "Installation complete\!"
echo "Dashboard URL: http://YOUR_SERVER_IP/"
echo "API URL: http://YOUR_SERVER_IP:3070/audit"
